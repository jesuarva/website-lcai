# website-lcai

Website development for a research group from the Autonomous University of Madrid.
Is an MVC framework based website, with neither a known MVC framework or a known CRM.

---
The website dynamically renders the views. The model data is fetched from a google drive spreadsheet and stored in session-storage. Views are rendered, binding the stored model data, based on specific events and rules.

The google drive spreadsheet is implemented as a database, where to store the model data.

To access main.css file without having to log in to the server or via an FTP connection, the main.css file is placed into a Dropbox folder from where is served.

Allow media files without need to upload them via an FTP connection to the server.

Logic coded in Vanilla Javascript and jQuery.
