<id> = 1oOnKqQim1RrsvF7Twfjp83SV-myjBFz6TUsZNM2jnFc

original URL
https://docs.google.com/spreadsheets/d/<id>/edit#gid=0
https://docs.google.com/spreadsheets/d/1oOnKqQim1RrsvF7Twfjp83SV-myjBFz6TUsZNM2jnFc/edit?usp=sharing
sheet2 = https://docs.google.com/spreadsheets/d/1oOnKqQim1RrsvF7Twfjp83SV-myjBFz6TUsZNM2jnFc/edit?usp=sharing
sheet1 = https://docs.google.com/spreadsheets/d/1oOnKqQim1RrsvF7Twfjp83SV-myjBFz6TUsZNM2jnFc/edit?usp=sharing

https://docs.google.com/spreadsheets/d/1oOnKqQim1RrsvF7Twfjp83SV-myjBFz6TUsZNM2jnFc/edit#gid=0

publiched to web
https://docs.google.com/spreadsheets/d/1oOnKqQim1RrsvF7Twfjp83SV-myjBFz6TUsZNM2jnFc/pubhtml

RSS feed
https://spreadsheets.google.com/feeds/cells/<id>/1/public/values
https://spreadsheets.google.com/feeds/cells/1oOnKqQim1RrsvF7Twfjp83SV-myjBFz6TUsZNM2jnFc/1/public/values

JSON
https://spreadsheets.google.com/feeds/cells/<id>/1/public/values?alt=json-in-script
https://spreadsheets.google.com/feeds/cells/1oOnKqQim1RrsvF7Twfjp83SV-myjBFz6TUsZNM2jnFc/1/public/values?alt=json-in-script